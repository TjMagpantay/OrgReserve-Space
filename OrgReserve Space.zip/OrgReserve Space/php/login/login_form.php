<?php
// Include the database connection file
require '/xampp/htdocs/OrgReserve Space/php/admin/function.php'; 

session_start(); // Start the session

// Initialize an error message array
$error = [];

// Check if the form is submitted
if (isset($_POST['submit'])) {
   $email = trim($_POST['email']);
   $password = trim($_POST['password']);

   if ($stmt = $conn->prepare("SELECT * FROM users WHERE email = ?")) {
       $stmt->bind_param("s", $email);
       $stmt->execute();
       $result = $stmt->get_result();

       if ($result->num_rows > 0) {
           $user = $result->fetch_assoc();

           // Debugging: Print stored hashed password and input password
           echo "Stored hashed password: " . $user['password'] . "<br>";
           echo "Input password: " . $password . "<br>";

           if (password_verify($password, $user['password'])) {
               // Password is correct, set session variables
               $_SESSION['srcode'] = $user['srcode'];
               $_SESSION['first_name'] = $user['first_name'];
               $_SESSION['last_name'] = $user['last_name'];
               $_SESSION['program'] = $user['program'];
               $_SESSION['email'] = $user['email'];
               $_SESSION['user_type'] = $user['user_type'];

               // Redirect based on user type
               if ($_SESSION['user_type'] === 'admin') {
                   header("Location: /php/admin/admin_dashboard.php");
               } elseif ($_SESSION['user_type'] === 'student') {
                   header("Location: /php/student/student_dashboard.php");
               } else {
                   $error[] = "User role not recognized.";
               }
               exit();
           } else {
               $error[] = "Invalid password. Please try again.";
           }
       } else {
           $error[] = "No user found with that email address.";
       }

       $stmt->close();
   } else {
       $error[] = "Failed to prepare the SQL statement.";
   }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="/bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="stylesheet" href="/css/style.css">
   <title>OrgReserve Space - Login</title>
</head>
<body>

<nav class="navbar navbar-expand-md bg-body-tertiary px-5">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">OrgReserve Space</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav right-align">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Contact</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Login
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/login/logout.php">Logout</a></li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="form-container">
   <form action="" method="post">
      <p class="p_login">Login <span class="x_icon"><i class="fa-solid fa-xmark"></i></span></p> 
      <?php
      if (!empty($error)){
         foreach ($error as $err) {
            echo '<span class="error-msg">' . htmlspecialchars($err) . '</span>';
         }
      }
      ?>
      <hr>
      <input type="email" name="email" placeholder="Enter your email" required>
      <input type="password" name="password" required placeholder="Enter your password">
      <p><a href="#">Forgot Your Password?</a></p>
      <input type="submit" name="submit" value="Continue" class="form-btn">
      <p class="group_name">by UIX Architexts</p>
   </form>
</div>

<script src="/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
