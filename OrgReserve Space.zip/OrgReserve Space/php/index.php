<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link href="/bootstrap-5.3.3-dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <!-- custom css file link  -->
   <link rel="stylesheet" href="/css/style.css">
   <title>OrgReserve Space</title>
</head>
<body>

<!-- Top -->
<div class="top vh-100 bg-body-tertiary d-flex flex-column justify-content-between">

   <!-- navigation bar -->
   <nav class="navbar navbar-expand-md px-5 p-4">
      <div class="container-fluid">
         <a class="navbar-brand" href="#">OrgReserve Space</a>
         <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav ms-auto">
               <li class="nav-item">
                  <a class="nav-link active" aria-current="page" href="#">Home</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">About</a>
               </li>
               <li class="nav-item">
                  <a class="nav-link" href="#">Contact</a>
               </li>
               <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle btn btn-gray" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                     Login
                  </a>
                  <ul class="dropdown-menu text-center" style="min-width: 100px;">
                     <li><a class="dropdown-item" href="/login/logout.php">Logout</a></li>
                  </ul>
               </li>
            </ul>
         </div>
      </div>
   </nav>

   <!-- Find Feature -->
   <div class="find-feature m-5">
      <span class="d-flex align-items-center mb-3">
         <h2 class="mb-0 me-2">Find</h2>
         <h6 class="mb-0 me-2">Shirts</h6>
         <h6 class="mb-0">Merch</h6>
      </span>

      <div class="card p-2">
         <div class="d-flex justify-content-between align-items-center">
            <div>
               <h5 class="card-title mb-2 d-none d-sm-block">Organizations</h5>
               <h5 class="card-title mb-2 d-block d-sm-none p-3 m-0">Org</h5> <!-- Show this on small screens -->
               <p class="card-text mb-0 d-none d-sm-block mx-3" style="font-size: 12px;">
                  <span class="me-3"><i class="fa-solid fa-circle"></i> CICS</span>
                  <span class="me-3"><i class="fa-solid fa-circle"></i> CABE</span>
                  <span class="me-3"><i class="fa-solid fa-circle"></i> CAS</span>
                  <span class="me-3"><i class="fa-solid fa-circle"></i> CIT</span>
                  <span><i class="fa-solid fa-circle"></i> CTE</span>
               </p>
            </div>
            <a href="#" class="btn reserve-btn btn-secondary">Reserve Now!</a>
         </div>
      </div>
   </div>
</div>

<!-- About Org -->
<div class="about-org vh-100">

   <div class="about-org-card card text-bg-dark" style="height: 40vh;">
      <img src="/images/banner.png" class="card-img" alt="...">
      <div class="card-img-overlay d-flex"> <!-- Added flex classes here -->
         <div class="card-content-text"> <!-- Added text-center class -->
            <h2 class="card-title">About the Org Reserve Space</h2>
            <p class="card-text" style="font-size: 15px;">A Reservation and Inventory Management System</p>
            <a href="#" class="btn about-org-learn-more-btn btn-secondary ">Reserve Now!</a>
         </div>
      </div>
   </div>

   <div class="why-org-reserve mt-5">
         <h2 class="text-center mb-5"> Why OrgReserve Space </h2>
         <div class="row row-cols-1 row-cols-md-3 g-2">
         <div class="col d-flex justify-content-center"> <!-- Center the card within the column -->
            <div class="card-why-org-reserve d-flex flex-column align-items-center text-center"> <!-- Added text-center for horizontal alignment -->
               <img src="/images/apparel.png" class="card-img-top mt-5" alt="..." style="max-width: 100%; height: auto;"> <!-- Ensures the image scales -->
               <div class="card-body d-flex flex-column align-items-center"> <!-- Added flex column for body -->
                     <h5 class="card-title">APPAREL AND MERCH</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
               </div>
            </div>
         </div>

         <div class="col d-flex justify-content-center"> <!-- Center the card within the column -->
            <div class="card-why-org-reserve d-flex flex-column align-items-center text-center"> <!-- Added text-center for horizontal alignment -->
               <img src="/images/calendar.png" class="card-img-top mt-5" alt="..." style="max-width: 100%; height: auto;"> <!-- Ensures the image scales -->
               <div class="card-body d-flex flex-column align-items-center"> <!-- Added flex column for body -->
                     <h5 class="card-title">EFFICIENT RESERVATION</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
               </div>
            </div>
         </div>

         <div class="col d-flex justify-content-center"> <!-- Center the card within the column -->
            <div class="card-why-org-reserve d-flex flex-column align-items-center text-center"> <!-- Added text-center for horizontal alignment -->
               <img src="/images/money.png" class="card-img-top mt-5" alt="..." style="max-width: 100%; height: auto;"> <!-- Ensures the image scales -->
               <div class="card-body d-flex flex-column align-items-center"> <!-- Added flex column for body -->
                     <h5 class="card-title">PAYMENT OPTION</h5>
                     <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit</p>
               </div>
            </div>
         </div>
   </div>
</div>

<!-- Footer -->

<footer class="bg-secondary text-dark mt-5 pb-2">
    <div class="row ">

      <!-- Logo and Social Media -->
      <div class="col-md-3" style="margin-right: 100px;">
    <h2 class="mb-4">LOGO</h2>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    <div class="d-flex">
        <a class="footer-btn nav-link" href="#">
            <i class="fa-brands fa-facebook"></i>
            <span class="ms-2">Facebook</span> <!-- Added span for margin -->
        </a>
        <a class="footer-btn nav-link" href="#">
            <i class="fa-brands fa-linkedin"></i>
            <span class="ms-2">LinkedIn</span> <!-- Added span for margin -->
        </a>
    </div>
</div>



      <!-- Company Links -->
      <div class="col-md-2">
        <h5 class="fw-bold mb-4">COMPANY</h5>
        <ul class="list-unstyled fw-semibold" >
          <li><a href="#" class="text-dark text-decoration-none">About Us</a></li>
          <li><a href="#" class="text-dark text-decoration-none">Legal Information</a></li>
          <li><a href="#" class="text-dark text-decoration-none">Contact Us</a></li>
          <li><a href="#" class="text-dark text-decoration-none">Blogs</a></li>
        </ul>
      </div>

      <!-- Help Center Links -->
      <div class="col-md-3">
        <h5 class="fw-bold mb-4">HELP CENTER</h5>
        <ul class="list-unstyled fw-semibold">
          <li><a href="#" class="text-dark text-decoration-none">Find an Apparel?</a></li>
          <li><a href="#" class="text-dark text-decoration-none">How to Reserve?</a></li>
          <li><a href="#" class="text-dark text-decoration-none">Why Us?</a></li>
          <li><a href="#" class="text-dark text-decoration-none">FAQs</a></li>
          <li><a href="#" class="text-dark text-decoration-none">Reserve Guides</a></li>
        </ul>
      </div>

      <!-- Contact Info -->
      <div class="col-md-3">
        <h5 class="fw-bold mb-4">CONTACT INFO</h5>
        <p class="fw-semibold">Phone: 1234567890</p>
        <p class="fw-semibold">Email: company@email.com</p>
        <p class="fw-semibold">Location: 100 Smart Street, LA, USA</p>
        <div class="d-flex fw-semibold">
          <a href="#" class="me-3 text-dark"><i class="fab fa-facebook fa-lg"></i></a>
          <a href="#" class="me-3 text-dark"><i class="fab fa-twitter fa-lg"></i></a>
          <a href="#" class="me-3 text-dark"><i class="fab fa-instagram fa-lg"></i></a>
          <a href="#" class="text-dark"><i class="fab fa-linkedin fa-lg"></i></a>
        </div>
      </div>

    </div>

    <!-- Footer Bottom -->
     <hr>
    <div class="container-fluid row mt-4 mb-4bg-secondary w-100 "> 
      <div class="col-md-6">
         <p class="text-muted">© 2024 | All rights reserved</p>
      </div>
      <div class="col-md-6 text-end">
         <p class="text-muted">Created with creativity by UIX Architexts</p>
      </div>
   </div>

</footer>


<!-- Font Awesome for Social Media Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>




<script src="/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

    
</body>
</html>