<?php require '/xampp/htdocs/OrgReserve Space/php/admin/function.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card-category {
            margin-top: 20px;
        }
        .card-title {
            font-weight: bold;
        }
        .card-text {
            color: #6c757d;
        }
        .favorite-icon {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 1.2rem;
            color: #ccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mt-5">Categories</h2>
        <div class="row">
            <?php
            $categories = mysqli_query($conn, "SELECT * FROM category");
            foreach($categories as $category) :
            ?>
                <div class="col-md-3 card-category">
                    <div class="card position-relative">
                        <i class="bi bi-heart favorite-icon"></i> <!-- Heart Icon -->
                        <img src="/php/admin/uploads/<?php echo htmlspecialchars($category['image']); ?>" class="card-img-top" alt="Category Image" style="height: 200px; object-fit: cover;">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($category['category_name']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($category['description']); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Bootstrap JS and Icons -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.js"></script>
</body>
</html>
