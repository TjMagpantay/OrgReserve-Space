<?php 
require 'db_conn.php'; // Include database connection
require 'function.php'; // Include functions

if(isset($_POST["submit"])) {
    if($_POST["submit"] == "add") {
        add();
    }
    else if($_POST["submit"] == "edit") {
        edit();
    }
    else {
        delete();
    }
}
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tech Innovators Society</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link href="/css/admin_dashboard.css" rel="stylesheet">
</head>
<body>
<!-- Sidebar -->
<div class="d-flex vh-100" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-dark border-right" id="sidebar-wrapper" style="position: fixed; width: 250px; height: 100vh; overflow-y: auto;">
        <div class="logo-sidebar sidebar-heading text-white">
            <h1>LOGO</h1>
        </div>
        <div class="list-group list-group-flush">
            <h6 class="text-gray main-heading">MAIN</h6>
            <a href="/php/admin/admin_dashboard.php" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Dashboard</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Students</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <hr class="text-white">
            <h6 class="text-gray main-heading">MANAGE</h6>
            <a href="/php/admin/category.php" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Category</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Products</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Reservation</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Transaction</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Revenue</span>
                <i class="fas fa-angle-right"></i>
            </a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper" class="container-fluid" style="margin-left: 250px;">
      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <a href="#" class="btn">
           <i class="fa-regular fa-code"></i>
        </a>

        <div class="ml-auto">
          <button class="btn btn-light"><i class="fa-regular fa-user"></i></button>
        </div>
      </nav>

      <!-- Integrated Category.php Content -->
      <div class="container table-container mt-4">
        <h2 class="mb-4">All Categories</h2>
        <div class="search-container">
            <label>Show</label>
            <input type="number" class="form-control-sm" style="width: 60px;" value="5"> <!-- Placeholder for number of rows to show -->
            <input type="text" class="form-control-sm" placeholder="Search" style="margin-left: 20px;">
        </div>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Category Name</th>
                    <th>Image</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Assume you have a MySQL connection established
                $categories = mysqli_query($conn, "SELECT * FROM category");
                $i = 1;
                foreach($categories as $category) :
                ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($category["category_name"]); ?></td>
                    <td><img src="uploads/<?php echo htmlspecialchars($category["image"]); ?>" width="100"></td>
                    <td>
                        <a href="editcategory.php?id=<?php echo $category['id']; ?>" class="btn btn-sm btn-edit btn-secondary action-btn">Edit</a>
                    </td>
                    <td>
                        <form action="" method="post" style="display:inline;">
                            <button type="submit" name="submit" value="<?php echo $category['id']; ?>" class="btn btn-sm btn-delete btn-secondary action-btn">Delete</button>  
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="addcategory.php" class="btn btn-secondary mt-3">Add Category</a>
      </div>
      <!-- /Integrated Category.php Content -->

    </div>
    <!-- /#page-content-wrapper -->
  </div>

  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <script src="/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
