<?php 
require 'db_conn.php'; // Include database connection
require 'function.php'; // Include functions

if(isset($_POST["submit"])) {
    if($_POST["submit"] == "add") {
        add();
    }
    else if($_POST["submit"] == "edit") {
        edit();
    }
    else {
        delete();
    }
}

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            margin: 20px auto;
            max-width: 900px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            min-height: 600px; /* Set minimum height for the form */
        }

        .form-title {
            background-color: #dedede;
            padding: 15px;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: left;
            border-radius: 8px 8px 0 0;
        }

        .form-label {
            font-weight: bold;
        }

        .img-placeholder {
            width: 100%;
            height: 200px; /* Increased height for the image preview */
            background-color: #e9ecef;
            border: 1px solid #ced4da;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 14px;
            color: #6c757d;
        }

        .btn-save {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
        }

        .btn-save:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container form-container justify-content-center">
        <div class="form-title">
            ADD CATEGORY
        </div>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="category_name" class="form-label">Select Category</label>
                    <select class="form-select" name="category_name" required>
                        <option value="" disabled selected>Choose Category</option>
                        <option value="Apparel">Apparel</option>
                        <option value="Merchandise">Merchandise</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="image" class="form-label">Image</label>
                    <input type="file" class="form-control" name="file" required>
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="6" placeholder="Type Here" required></textarea>
                </div>
                <div class="col-md-6">
                    <label for="image-preview" class="form-label">Image Preview</label>
                    <div class="img-placeholder">Image Preview</div> <!-- Placeholder for image preview -->
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 text-end">
                    <button type="submit" name="submit" value="add" class="btn btn-save">Save Category</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
