<?php
require 'db_conn.php'; // Include the database connection

function add() {
    global $conn;
    $category_name = $_POST["category_name"];
    $description = $_POST["description"];
    $filename = $_FILES["file"]["name"];
    $tmpName = $_FILES["file"]["tmp_name"];
    $newfilename = uniqid() . "-" . $filename;

    move_uploaded_file($tmpName, 'uploads/' . $newfilename);
    $query = "INSERT INTO category (category_name, description, image) VALUES ('$category_name', '$description', '$newfilename')";
    mysqli_query($conn, $query);
    echo "<script> alert('Category Added Successfully'); document.location.href = 'category.php'; </script>";
}

function edit() {
    global $conn;

    $id = intval($_GET["id"]);
    $category_name = mysqli_real_escape_string($conn, $_POST["category_name"]);
    $description = mysqli_real_escape_string($conn, $_POST["description"]);

    if ($_FILES["file"]["error"] != 4) {
        $filename = $_FILES["file"]["name"];
        $tmpName = $_FILES["file"]["tmp_name"];
        $newfilename = uniqid() . "-" . $filename;
        move_uploaded_file($tmpName, 'uploads/' . $newfilename);
        $query = "UPDATE category SET category_name = '$category_name', description = '$description', image = '$newfilename' WHERE id = $id";
    } else {
        $query = "UPDATE category SET category_name = '$category_name', description = '$description' WHERE id = $id";
    }

    mysqli_query($conn, $query);
    echo "<script>alert('Category Edited Successfully'); document.location.href = 'category.php';</script>";
}

function delete() {
    global $conn;
    $id = intval($_POST["submit"]);
    $query = "DELETE FROM category WHERE id = $id";
    mysqli_query($conn, $query);
    echo "<script>alert('Category Deleted Successfully');</script>";
}
?>
