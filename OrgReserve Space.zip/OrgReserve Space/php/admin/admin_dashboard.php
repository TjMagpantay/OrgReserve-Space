<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tech Innovators Society</title>
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link href="/css/admin_dashboard.css" rel="stylesheet">
</head>
<body>
<!-- Sidebar -->
<div class="d-flex vh-100" id="wrapper">
    <!-- Sidebar -->
    <div class="bg-dark border-right" id="sidebar-wrapper" style="position: fixed; width: 250px; height: 100vh; overflow-y: auto;">
        <div class="logo-sidebar sidebar-heading text-white">
            <h1>LOGO</h1>
        </div>
        <div class="list-group list-group-flush">
            <h6 class="text-gray main-heading">MAIN</h6>
            <a href="/php/admin/admin_dashboard.php" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Dashboard</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Students</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <hr class="text-white">
            <h6 class="text-gray main-heading">MANAGE</h6>
            <a href="/php/admin/category.php" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Category</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Products</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Reservation</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Transaction</span>
                <i class="fas fa-angle-right"></i>
            </a>
            <a href="#" class="list-group-item list-group-item-action bg-dark text-white d-flex justify-content-between align-items-center">
                <span>Revenue</span>
                <i class="fas fa-angle-right"></i>
            </a>
        </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper" class="container-fluid" style="margin-left: 270px;">
      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <a href="#" class="btn">
           <i class="fa-regular fa-code"></i>
        </a>

        <div class="ml-auto">
          <button class="btn btn-light"><i class="fa-regular fa-user"></i></button>
        </div>
      </nav>

    <div class="row row-cols-2 row-cols-lg-4 g-4 p-5">
        <div class="col">
            <div class="card h-100">
            <img src="/images/banner.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Manage Reservation</h5>
                <p class="card-desc card-text">Oversee and adjust all user reservations.</p>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card h-100">
            <img src="/images/banner.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Stocks Panel</h5>
                <p class="card-desc card-text">Track and manage inventory levels.</p>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card h-100">
            <img src="/images/banner.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">General Statistics</h5>
                <p class="card-desc card-text">View key performance metrics and trends.</p>
            </div>
            </div>
        </div>
        <div class="col">
            <div class="card h-100">
            <img src="/images/banner.png" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title">Revenue Report</h5>
                <p class="card-desc card-text">Analyze income and financial performance.</p>
            </div>
            </div>
        </div>
    <!-- /#page-content-wrapper -->
  </div>
    
  </script>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <script src="/bootstrap-5.3.3-dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>







