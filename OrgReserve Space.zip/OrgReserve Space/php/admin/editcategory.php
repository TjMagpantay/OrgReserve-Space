<?php 
require 'db_conn.php'; // Include database connection
require 'function.php'; // Include functions

if(isset($_POST["submit"])) {
    if($_POST["submit"] == "add") {
        add();
    }
    else if($_POST["submit"] == "edit") {
        edit();
    }
    else {
        delete();
    }
}

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$id = intval($_GET["id"]);
$query = "SELECT * FROM category WHERE id = $id";
$result = mysqli_query($conn, $query);

// Check if query was successful
if (!$result) {
    die("<script>alert('Failed to fetch category data.'); document.location.href = 'category.php';</script>");
}

$category = mysqli_fetch_assoc($result);

// Check if category data was retrieved
if (!$category) {
    die("<script>alert('Category not found.'); document.location.href = 'category.php';</script>");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Category</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-container {
            margin: 20px auto;
            max-width: 900px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }

        .form-title {
            background-color: #dedede;
            padding: 15px;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: left;
            border-radius: 8px 8px 0 0;
        }

        .form-label {
            font-weight: bold;
        }

        .img-placeholder {
            width: 100%;
            height: 100%;
            background-color: #e9ecef;
            border: 1px solid #ced4da;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 14px;
            color: #6c757d;
        }

        .btn-save {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 10px 20px;
        }

        .btn-save:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="form-title">
            EDIT CATEGORY
        </div>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="category_name" class="form-label">Category Name</label>
                    <input type="text" class="form-control" name="category_name" value="<?php echo htmlspecialchars($category['category_name']); ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="category_name" class="form-label">Select Category</label>
                    <select class="form-select" name="category_name" required>
                        <option value="" disabled selected>Choose Category</option>
                        <!-- Add your categories here -->
                        <option value="Apparel">Apparel</option>
                        <option value="Merchandise">Merchandise</option>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="image" class="form-label">Change Image (Optional)</label>
                    <input type="file" class="form-control" name="file">
                </div>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="description" class="form-label">Description</label>
                    <textarea class="form-control" name="description" rows="6" required><?php echo htmlspecialchars($category['description']); ?></textarea>
                </div>
                <div class="col-md-6">
                    <label for="image-preview" class="form-label">Current Image</label>
                    <div class="img-placeholder">
                        <img src="uploads/<?php echo htmlspecialchars($category['image']); ?>" alt="Current Image" width="100%">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12 text-end">
                    <button type="submit" name="submit" value="edit" class="btn btn-save">Save Changes</button>
                </div>
            </div>
        </form>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
