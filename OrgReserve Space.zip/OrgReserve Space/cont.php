<?php
$conn = mysqli_connect("localhost", "root", "", "org_reserve");

// Check if connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

